/*

  Title: Pawfect Dog Age Converter
  	
  Program Summary: This program aims to provide the local community with the ability to convert their dog's age in human years into their dog's age in dog years. This helps individuals gain a better picture of which stage of life their dog is in.
	
  Key Program Elements Utilized: Variables, use of document.getElementById, a variety of Data Types, If ... Else If ... Else statements, Functions, Arithmetic Operators, setAttribute property, change the properties of min and max of HTML elements with JavaScript,  when it comes to JavaScript. HTML/CSS syntax was utilized in order to create an excellent web experience.


*/






// Functions Declarations





/*

 * Summary: This function hides the button based on its ID, which is "myButton." It also makes HTMl elements with the  ID of "first" become visible.
 * Parameters: None
 * Return: None; instead, elements which have the ID of "myButton" and "first" obtain an altered value of visibility.

 */
function hideMyButton() {

  document.getElementById("myButton").style.visibility = "hidden"; //This line alters the visibility of the element with the id of "myButton."
  document.getElementById("first").style.visibility = "visible"; //This line alters the visibility of the element with the id of "myID."

} // End of hideMyButton function







/*

 * Summary: This function controls the HTMl form soliciting input from the user. 
 * Parameters: None.
 * Return: No specific return; rather, the program primarily edits the properties of HTML elements.
 
 */
function nextquestion() {

  switch (question) {

    case 0:

      
      dogName = document.getElementById("boxvalue").value; // Assigns the current value of the HTML element with the ID of "boxvalue" to the variable "dogName".

      document.getElementById("thequestion").innerHTML = "What is your dog's age in human years?";

      document.getElementById("boxvalue").type = "number";

      document.getElementById("boxvalue").value = ""; // Alters the value of the HTML element with the ID of "boxvalue".
      
      document.getElementById("boxvalue").setAttribute("min", "0");
      
      document.getElementById("boxvalue").setAttribute("step", "1");
  
      document.getElementById("boxvalue").placeholder = "ex. 1";

      document.getElementById("boxvalue").setAttribute("max", "50");

      question += 1;


      
      break;



      
    case 1:

      
      dogHuman = document.getElementById("boxvalue").value;

      document.getElementById("thequestion").innerHTML = `What is ` + dogName + `'s breed?`;

      document.getElementById("boxvalue").placeholder = "ex. Labrador Retriever";

      document.getElementById("boxvalue").type = "text";

      document.getElementById("boxvalue").value = "";

      document.getElementById("boxvalue").setAttribute("list", "income");

      question += 1;


      
      break;



      
      
    case 2:

      
      dogBreed = document.getElementById("boxvalue").value;

      document.getElementById("boxvalue").style.visibility = "hidden";

      document.getElementById("submiting").style.visibility = "hidden";

      document.getElementById("thequestion").style.visibility = "hidden";
           
      document.getElementById("thequestion").style.fontSize = "2vw";
      
      document.getElementById("firstWord").style.fontSize = "2vw";
      
      document.getElementById("secondWord").style.fontSize = "2vw";
      
      document.getElementById("thirdWord").style.fontSize = "2vw";
      
      document.getElementById("fourthWord").style.fontSize = "2vw";
      
      document.getElementById("fifthWord").style.fontSize = "2vw";
      
      document.getElementById("nextWord").style.fontSize = "2vw";
      
      document.getElementById("thequestion").style.visibility = "visible";
      
      document.getElementById("firstWord").style.visibility = "visible";
      
      document.getElementById("secondWord").style.visibility = "visible";

      document.getElementById("thirdWord").style.visibility = "visible";
      
      document.getElementById("fourthWord").style.visibility = "visible";
      
      document.getElementById("fifthWord").style.visibility = "visible";
      
      document.getElementById("nextWord").style.visibility = "visible";


          
      document.getElementById("thequestion").innerHTML = "Your ";
      
      document.getElementById("firstWord").innerHTML = `${dogBreed}`;
      
      document.getElementById("nextWord").innerHTML = ' named ';
      
      document.getElementById("secondWord").innerHTML = `${dogName}`;
      
      document.getElementById("thirdWord").innerHTML = ' is ';
  
      dogHuman ? calculate() : document.location.reload();
      
      
      
      break;

 

    default: 

      console.log("Program is not working. Page will reload for the user.");
      document.location.reload();

  } // End of the switch(question) statement.       

} // End of the function titled "nextquestion".








/*

 * Summary: It then performs the human years to dog years conversion for the user based on their input, and displays the results.
 * Parameters: None.
 * Return: No specific return; rather, the program primarily performs conversions and then modifies the properties of HTML elements.
 
 */
function calculate () {
      
  
      if (dogHuman <= 0) {
       
          document.getElementById("fourthWord").innerHTML = '0';
       
          document.getElementById("fourthWord").innerHTML = ' years of age in human years (between 0 and 10.5 years old in dog years). Once they are one year old, you will be able to get a better estimate of their age.';
      
        } // End of what would happen if the "dogHuman" variable is 0.


      else if (dogHuman == 1) {
       
          document.getElementById("fourthWord").innerHTML = '10.5';
       
          document.getElementById("fifthWord").innerHTML = ' in dog years.';
       
        } // End of what would happen if the "dogHuman" variable is 1.

          
       else if (dogHuman == 2) {
         
          document.getElementById("fourthWord").innerHTML = '21';
         
          document.getElementById("fifthWord").innerHTML = ' in dog years.';
       
        } // End of what would happen if the "dogHuman" variable is 2.

         
       else if (dogHuman >= 3 && dogHuman <= 50) {
         
          document.getElementById("fourthWord").innerHTML = (((dogHuman - 2) * 4) + 21) ;
         
          document.getElementById("fifthWord").innerHTML = ' in dog years!';
         
        } // End of what would happen if the "dogHuman" variable is greater than or equal to 3.

      
       else {
        
          console.log("Program is not working. Page will reload for the user.");
          document.location.reload();
          
        } // End of what would happen if the "dogHuman" did not euqal any of the above values.

 
} // End of the calculate() function.









//Beginning Of Program




// Variable Declarations - The variables used throughout the program are declared below.


let dogHuman = 0;

let question = 0;

let dogName = 0;

let dogBreed = 0;





//Beginning of Main




// The nextquestion() function is our main, since it is where the primary input and output occurs.




//End of Main







// End of Program





/* NOTES:

    *We can add on additional features in the future, such as pictures based on dog breed which the user selects. This would work through showing and hiding images through the getElementById method.



    Test Code Can Be Found Below:

      console.log(dogName + "is your dog's name!");

  
  
*/


/* 
	Title: Kelvin Temperature Converter for CNN - Will and Zeyus
	Program Summary: This program aims to provide the CNN Weather Center with the ability to convert temperature between various units of measurement. Our webpage enables a seamless UI/UX experience for the user of the website.
	Important (KEY) Program Elemnts Used: Variables, Data Types, IF statements, and Arithmetic Operators when it comes to JavaScript. Basic HTML/CSS syntax was utilized in order to create an excellent web experience.
*/ 

//Beginning Of Program




// Variable Declarations

let kelvin; // static value for now. Will be updated to a dynamic value later.

let celsius; // static value for now. Will be updated to a dynamic value later.

let fahrenheit; // static value for now. Will be updated to a dynamic value later.

let todayAvg; // Variable for today's average temperature.




// Functions Declarations


// processWeatherData function is defined to input weather informations getted from above website to decleared variables previously.

function processWeatherData(response) {

  // input weather informations getted from above website to 'days' variable
  var days = response.days; 

  // print all weather imformations on console for just checking
  for (var i=0;i<days.length;i++) {

    console.log(days[i].datetime+": tempmax="+days[i].tempmax+", tempmin="+days[i].tempmin);

  }

  // here, data value of days[1] is today's one.
  // extracting min, max, avg temperatures.

  let todayMax = days[0].tempmax;
  console.log(Math.round(todayMax));

  let todayMin = days[0].tempmin;
  console.log(Math.round(todayMin));

  todayAvg = Math.round((todayMax + todayMin) / 2);
  console.log(Math.round(todayAvg));

}




// setTemperature function is defined to change values for thermometer view

function setTemperature(averageTempToday, unit) {

  let height = averageTempToday;

 
  temperature.style.height = height + "%";

  temperature.dataset.value = averageTempToday + unit;
  
}




// convertCelToFah function is defined to convert Celsius unit to Fahrenheit unit

function convertCelToFah (celsiusUnit) {

  return Math.round(celsiusUnit * (9/5) + 32);

}




// askForTempType function is defined for using prompt to get user's needs and convert unit depending on needs.

function askForTempType () {

let region = prompt('Hello! Please select whether you would like the temperature in Farenheit (USA) or Celsius (Canada)');  

  // if user's input data is USA, convert our Celsius unit data to Fahrenheit unit
  if (region == "Farenheit" || region == "farenheit" || region == "FARENHEIT") { 

    setTemperature(convertCelToFah(todayAvg), "°F"); // using setTemperature function set thermometer's value and height
    console.log('done');

  }
  
  // if user's input data is Celsius, we don't need to change unit
  else if (region == "Celsius" || region == "celsius" || region == "CELSISUS") { 
  
    setTemperature(todayAvg, "°C");  // using setTemperature function set thermometer's value and height
    console.log('done');
  }

  // if user clicked 'cancel' button, show celsius unit as default.
  else if (region === null) {

    setTemperature(todayAvg, "°C");
    console.log('done');
  }  
  
  // if user's input data is not both celsius and farenheit, show alert and ask again.
  else { 
  
    alert('Please let us know whether you would like to be informed about the temperature in Celsius or Farenheit');


    
  }

}






// Firstly, we need to get today's weather temperature information from https://weather.visualcrossing.com
// After getting informations, store in variables and open prompt for asking unit type that user want.

// Due to the asynchronous nature of JavaScript, we inserted the code we wrote in order in the referenced API code.
// The askForTempType function has to call after this fetch finished.

fetch("https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline/north%20vancouver?unitGroup=metric&include=alerts%2Ccurrent%2Cdays%2Chours%2Cevents&key=QJ4MMTTUBT39MAWTZLFYVVDG6&contentType=json",
{

  method: 'GET', 

  headers: {},

})

.then(response => {

  if (!response.ok) {

    throw response; //check the http response code and if isn't ok then throw the response as an error

  }            

  return response.json();   //parse the result as JSON

})

.then(response => {   //response now contains parsed JSON ready for use

  processWeatherData(response);   //call processWeatherData function

  

  // we get the today's temperature informations (max, min, avg) via fatch, but these are Celsius units.
  // So, we need to convert unit depending on user's needs.
  // we just use average value for converting to other unit.
  
  askForTempType();    //call askForTempType function

  kelvin = (todayAvg + 273); 

  celsius = kelvin - 273;

  fahrenheit = celsius * (9/5) + 32; 

})







// Ending Of Program


/* NOTES:
    Ideas for expansion located in the learning document 
    New JavaScript tools on W3 Schools 
    Variables for other conditions like the wind
    Another type of conversion could be worked on, such as Celsius to Newtons
    Utilize HTML & CSS
    UIUX: Title, Welcome, Intro, Explanation, Re-iterate input, output, Thanks
    Look at actual CNN weather page
    Watch CodeCademy video
    aski art text generstior, art for console.
    https://codepen.io/Arkellys/pen/rgpNBK - Link to cool thermometer
    change the picture displayhed based on the weather
    when person comes into website, they can be asked in a css input box. are you in canada or usa. select below. if they are from canada, it shows clesius, if canada it shows celsisus.
*/


//test code